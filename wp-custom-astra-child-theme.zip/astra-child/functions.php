<?php
/**
 * Astra Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Astra Child
 * @since 1.0.0
 */
// Include essential files, must not be missing
require_once trailingslashit(get_stylesheet_directory()) . 'inc/utility-functions.php';
require_once trailingslashit(get_stylesheet_directory()) . 'inc/custom-post-types.php';
require_once trailingslashit(get_stylesheet_directory()) . 'inc/metaboxes.php';
require_once trailingslashit(get_stylesheet_directory()) . 'inc/menus.php';
require_once trailingslashit(get_stylesheet_directory()) . 'shortcodes.php';

function frontend_enqueues() {
	// ________________________________________________________________________________________________________ \\
	// Theme custom scripts
	wp_enqueue_style( 'child-css', get_stylesheet_directory_uri() . '/style.css', array('astra-theme-css'), time());
	wp_enqueue_style( 'custom-css', get_stylesheet_directory_uri() . '/assets/css/custom.css', '', time());
	wp_enqueue_style( 'responsive-css', get_stylesheet_directory_uri() . '/assets/css/responsive.css', '', time());
	wp_enqueue_script( 'custom-js', get_stylesheet_directory_uri() . '/assets/js/custom.js', ['jquery'], time(), true );

	// Localize js file which needs server information like admin URL and nonce for ajax request
	wp_localize_script('custom-js', 'ajax', [
		'url' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('wp-ajax-nonce')
	]);
	// ________________________________________________________________________________________________________ \\

	// Slick Slider Scripts
	wp_enqueue_style( 'slick-css', get_stylesheet_directory_uri() . '/assets/css/slick.css', '', '1.0');
	wp_enqueue_script( 'slick-js', get_stylesheet_directory_uri() . '/assets/js/slick.min.js', ['jquery'], '1.0');

	// Fontawesome kit
	wp_enqueue_script( 'fontawesome-kit-js', get_stylesheet_directory_uri() . '/assets/js/fontawesome-kit.js', ['jquery'], '1.0');

	// Mixitup
	wp_enqueue_script( 'mixitup-js', 'https://cdn.jsdelivr.net/jquery.mixitup/latest/jquery.mixitup.min.js', ['jquery'], '1.0');

}
add_action( 'wp_enqueue_scripts', 'frontend_enqueues', 15 );

function backend_enqueues() {
	// Fontawesome kit
	wp_enqueue_script( 'fontawesome-kit-js', get_stylesheet_directory_uri() . '/assets/js/fontawesome-kit.js', ['jquery'], '1.0');
}
add_action( 'admin_enqueue_scripts', 'backend_enqueues', 15 );

// Insert some posts by default to get built-in shortcodes in working form
function insert_default_posts() {

    // Check if the posts have already been created
    $default_posts_created = get_option( 'default_posts_created' );

    // If the option is already set, don't run the code again
    if ( $default_posts_created ) {
        return;
    }

    // Insert category for portfolio automatically by default
    $cat_art = wp_insert_term(
        'Art',
        'wise-portfolios-cat'
    );

    // Get the term ID of the newly created or existing category
    $get_cat = get_term_by( 'name', 'Art', 'wise-portfolios-cat' );
    $get_cat_id = $get_cat->term_id;

    // Insert posts for portfolio automatically in default
    $post_data = [
        'post_type'    => '',
        'post_title'   => '',
        'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur...',
        'post_status'  => 'publish',
        'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua...',
    ];
    $portfolio_post_data = $post_data;
    $portfolio_post_data['post_type'] = 'wise-portfolios';

    // Create portfolio posts
    for ( $i = 1; $i <= 6; $i++ ) {
        $portfolio_post_data['post_title'] = 'Wise Portfolio ' . $i;
        $portfolio_post = wp_insert_post( $portfolio_post_data );

        if ( ! is_wp_error( $portfolio_post ) ) {
            // Associate the post with the newly created category
            wp_set_object_terms( $portfolio_post, array( $get_cat_id ), 'wise-portfolios-cat' );
        }
    }

    // Testimonials Posts
    $testimonials_post_data = $post_data;
    $testimonials_post_data['post_type'] = 'wise-testimonials';
    $testimonials_post_data['meta_input'] = [
        'testimonial_person_name'   => 'Farooq Bin Munir',
        'testimonial_designation'   => 'Web App Developer',
        'testimonial_review_text'   => 'Lorem ipsum dolor sit amet, consectetur...',
    ];

    // Create testimonial posts
    for ( $i = 1; $i <= 6; $i++ ) {
        $testimonials_post_data['post_title'] = 'Wise Testimonial ' . $i;
        wp_insert_post( $testimonials_post_data );
    }

    // Set the option to indicate that the default posts have been created
    update_option( 'default_posts_created', true );
}
add_action( 'after_switch_theme', 'insert_default_posts' );


