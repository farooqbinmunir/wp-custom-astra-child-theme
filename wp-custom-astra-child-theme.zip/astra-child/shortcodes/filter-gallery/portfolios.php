<?php
// Extract variables
$layout_class = 'layout_' . ($layout == 'masonry' ? 'masonry' : 'grid');
$filter = $atts['filter'];
$categories = $atts['categories'];

// Get Portfolio Categories
$terms = get_terms([
    'taxonomy' => 'wise-portfolios-cat',
    'hide_empty' => true,
    'slug' => !empty($categories) ? explode(',', $categories) : '',
]);

// Portfolio section
?>
<section id="wise_portfolios" class="wise_portfolios <?= $layout_class; ?>">
    <div class="wise_portfolios_container">
        
        <?php if ($filter === 'yes') : // Show filter only if filter="yes" ?>
        <div class="portfolio-filters">
            <button class="filter-button active" data-filter="all">All</button>
            <?php foreach ($terms as $term): ?>
                <button class="filter-button" data-filter=".category-<?php echo $term->slug; ?>">
                    <?php echo $term->name; ?>
                </button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
        <div style="clear:both;"></div>
        
        <div class="portfolio-items">
            <?php
            // Prepare query arguments
            $args = [
                'post_type' => 'wise-portfolios',
                'posts_per_page' => -1,
                'post_status' => 'publish',
                'tax_query' => !empty($category_array) ? [
                    [
                        'taxonomy' => 'wise-portfolios-cat',
                        'field' => 'slug',
                        'terms' => $category_array,
                    ],
                ] : [],
            ];

            // Fetch portfolio items
            $portfolio_query = new WP_Query($args);
            if ($portfolio_query->have_posts()) :
                while ($portfolio_query->have_posts()) : $portfolio_query->the_post();
                    $id = get_the_ID();
                    $title = get_the_title();
                    $link = get_the_permalink();

                    // Fetch thumbnail image
                    $img_data = wp_get_attachment_image_src(get_post_thumbnail_id($id), 'full');
					$imgURL = '';
                    if ($img_data) {
                        $imgURL = $img_data[0];
                    }

                    $terms = get_the_terms(get_the_ID(), 'wise-portfolios-cat');
                    $classes = '';
                    if (!empty($terms)) {
                        foreach ($terms as $term) {
                            $classes .= 'category-' . $term->slug . ' ';
                        }
                    }
                    ?>
                    <div class="portfolio-item active <?php echo trim($classes); ?>">
                        <div class="portfolio-item-wrap">
                            <div class="portfolio-item-thumbnail">
                                <img class="portfolio-item-thumbnail-img" src="<?= $imgURL; ?>" alt="Image - <?= $title; ?>" title="<?= $title; ?>" />
                            </div>
                            <a href="<?= $link; ?>" class="portfolio-item-text">
                                <h3 class="portfolio-item-title"><?= $title; ?></h3>
                            </a>
                        </div>
                    </div>
                <?php endwhile;
                wp_reset_postdata();
            endif;
            ?>
        </div>

        <div style="clear:both;"></div>
    </div>
</section>
