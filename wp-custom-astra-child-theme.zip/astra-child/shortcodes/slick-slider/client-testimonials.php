<!-- Shortcode: Testimonials [testimonials] -->
<?php
$autoplay = strtolower($atts['autoplay']) == 'true' ? 'true' : 'false';
$dots = strtolower($atts['dots']) == 'true' ? 'true' : 'false';
$arrows = strtolower($atts['arrows']) == 'true' ? 'true' : 'false';
$slidesToShow = intval($atts['slidestoshow']);
$slidesToScroll = intval($atts['slidestoscroll']);
$fade = strtolower($atts['fade']) == 'true' ? 'true' : 'false';
$infinite = strtolower($atts['infinite']) == 'true' ? 'true' : 'false';
if($fade == 'true'){
	$slidesToShow = 1;
}

?>

<div class="testimonials_slider_container">
	<div id="testimonials_slider" class="testimonials_slider">

		<?php
		$testimonials = new WP_Query([
			'post_type' => 'wise-testimonials',
			'post_status' => 'publish',
			'posts_per_page' => -1,
		]);
		if($testimonials->have_posts()){
			while($testimonials->have_posts()){ $testimonials->the_post();
				$id = get_the_ID();
				$title = get_the_title();
				$permalink = get_the_permalink();
				$excerpt = get_the_excerpt();
				$feature_img_url = wp_get_attachment_image_src(get_post_thumbnail_id($id), 'full');
				if($feature_img_url){
					$feature_img_url = $feature_img_url[0];
				}

		        // Get the metadata
		        $testimonial_rating_image = get_post_meta($id, 'testimonial_rating_image', true);
				$testimonial_person_name = get_post_meta($id, 'testimonial_person_name', true);
				$testimonial_designation = get_post_meta($id, 'testimonial_designation', true);
				$testimonial_review_text = get_post_meta($id, 'testimonial_review_text', true);
				?>


			  	<div id="testimonials_slider_item-<?= $id; ?>" class="testimonials_slider_item" data-id="<?= $id; ?>">
			  		<div class="testimonials_slider_item_wrap">
			  			<div class="testimonials_slider_item_header">
			  				<figure class="testimonials_slider_item_thumbnail_wrap">
			  					<img class="testimonials_slider_item_thumbnail_img" src="<?php echo $feature_img_url; ?>" title="<?php echo $title; ?>" width="100%" height="100%" />
			  				</figure>
			  				<hgroup>
			  					<h5 class="testimonials_slider_item_hero_name"><?= $testimonial_person_name; ?></h5>
			  					<p class="testimonials_slider_item_hero_designation"><?= $testimonial_designation; ?></p>
			  				</hgroup>
			  			</div>
			  			<div class="testimonials_slider_item_meta">
			  				<hgroup>
			  					<h5 class="testimonials_slider_item_review_title"><?= $title; ?></h5>
			  					<figure class="testimonials_slider_item_review_rating_img_wrap">
				  					<img class="testimonials_slider_item_review_rating_img" src="<?= $testimonial_rating_image; ?>" title="<?= $title; ?>" />
				  				</figure>
			  					<p class="testimonials_slider_item_review_text clamped-text"><?= $testimonial_review_text; ?></p>
			  				</hgroup>
			  			</div>
			  		</div>
			  	</div>

			<?php } 
				wp_reset_postdata();
		}else{

		} ?>
	</div>
</div>

<script>
	jQuery(document).ready(function($) {
		// Initializing Slick Slider on Testimonials slider
		const testimonials = $('.testimonials_slider');
		const sliderSettings = {};

		sliderSettings.autoplay = <?= $autoplay; ?>;
		sliderSettings.dots = <?= $dots; ?>;
		sliderSettings.arrows = <?= $arrows; ?>;
		sliderSettings.slidesToShow = <?= $slidesToShow; ?>;
		sliderSettings.slidesToScroll = <?= $slidesToScroll; ?>;
		sliderSettings.fade = <?= $fade; ?>;
		sliderSettings.infinite = <?= $infinite; ?>;
		sliderSettings.responsive = [
			    {
			      breakpoint: 1024,
			      settings: {
			        slidesToShow: 3,
			      }
			    },
			    {
			      breakpoint: 600,
			      settings: {
			        slidesToShow: 2,
			      }
			    },
			    {
			      breakpoint: 480,
			      settings: {
			        slidesToShow: 1,
			      }
			    }
			    // You can unslick at a given breakpoint now by adding:
			    // settings: "unslick"
			    // instead of a settings object
		];
		// console.log(sliderSettings);
		testimonials.slick(sliderSettings);
	});

</script>
