<?php

function admin_menu_callback(){
	add_menu_page(
		'Wise Settings',
		'Wise Settings',
		'manage_options',
		'wise-settings',
		'wise_settings_callback',
		null,
		5,
	);
}
add_action('admin_menu', 'admin_menu_callback');

function wise_settings_callback(){ ?>

	<div class="wrap">
		<div id="wise_menu_page">
			<div id="fbm_notice" class="notice" style="display: none;"></div>
			<div class="wise_menu_page_wrap">
				<div class="wise_menu_page_header">
					<h2 class="wise_menu_page_title"><?= get_admin_page_title(); ?></h2>
				</div>
				<hr class="wise_line" />
				<div class="wise_menu_page_body">
					<!-- Write your html for menu page here -->

					<h4 class="welcome_message">Welcome! Dear User,</h4>

					<div id="shortcodes">
						<div class="shortcodes_wrap">
							<table class="shortcodes_listing_table widefat striped">
								<thead>
									<tr>
										<th class="shortcode_th_module">Module</th>
										<th class="shortcode_th_code">Shortcode</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td class="shortcode_td_module_name">Testimonials Slider</td>
										<td class="shortcode_td_module_shortcode">
											<p><span class="wise_shortcode">[testimonials autoplay="true" slidestoshow="3" slidestoscroll="1" dots="true" arrows="true" fade="false" infinite="true"]</span><button class="copy_shortcode_btn"><i class="fa-solid fa-copy"></i></button></p>
										</td>
									</tr>
									<tr>
										<td class="shortcode_td_module_name">Portfolio Filter Gallery</td>
										<td class="shortcode_td_module_shortcode">
											<p><span class="wise_shortcode">[portfolios filter="yes" layout="grid" categories=""]</span><button class="copy_shortcode_btn"><i class="fa-solid fa-copy"></i></button></p>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>

					<div id="shortcodes_details">
						<h1 style="font-weight: 700; text-align: center;">How to use?</h1>
						<div class="shortcodes_details_wrap">
							<ol id="shortcode_detail_items">
								<li class="shortcode_detail_item">
									<div class="shortcode_detail_item_wrap">
										<h1 class="shortcode_detail_item_name">Testimonials Slider</h1>
										<div class="shortcode_detail_item_content">
											<p class="shortcode_detail_item_description">Outputs Slick slider with data from Post Type -> Wise Testimonials</p>
											<h3 class="shortcode_detail_item_param_heading">Params</h3>
											<div class="params_container">
												<hgroup>
													<p class="shortcode_detail_item_param"><strong>autoplay: </strong> <span>true/false</span></p>
													<p class="shortcode_detail_item_param">Default: <span>true</span></p>
												</hgroup>

												<hgroup>
													<p class="shortcode_detail_item_param"><strong>slidesToShow: </strong> <span>number</span></p>
													<p class="shortcode_detail_item_param">Default: <span>3</span></p>
												</hgroup>

												<hgroup>
													<p class="shortcode_detail_item_param"><strong>slidesToScroll: </strong> <span>number</span></p>
													<p class="shortcode_detail_item_param">Default: <span>1</span></p>
												</hgroup>

												<hgroup>
													<p class="shortcode_detail_item_param"><strong>dots: </strong> <span>true/false</span></p>
													<p class="shortcode_detail_item_param">Default: <span>true</span></p>
												</hgroup>
												<hgroup>
													<p class="shortcode_detail_item_param"><strong>arrows: </strong> <span>true/false</span></p>
													<p class="shortcode_detail_item_param">Default: <span>true</span></p>
												</hgroup>
												<hgroup>
													<p class="shortcode_detail_item_param"><strong>fade: </strong> <span>true/false</span></p>
													<p class="shortcode_detail_item_param">Default: <span>false</span></p>
												</hgroup>
												<hgroup>
													<p class="shortcode_detail_item_param"><strong>infinite: </strong> <span>true/false</span></p>
													<p class="shortcode_detail_item_param">Default: <span>true</span></p>
												</hgroup>
											</div>
										</div>
									</div>
								</li>
								<li class="shortcode_detail_item">
									<div class="shortcode_detail_item_wrap">
										<h1 class="shortcode_detail_item_name">Portfolio Filter Gallery</h1>
										<div class="shortcode_detail_item_content">
											<p class="shortcode_detail_item_description">Outputs filterable gallery for portfolios with data from Post Type -> Wise Portfolios</p>
											<h3 class="shortcode_detail_item_param_heading">Params</h3>
											<div class="params_container">
												<hgroup>
													<p class="shortcode_detail_item_param"><strong>filter: </strong> <span>true/false</span></p>
													<p class="shortcode_detail_item_param">Default: <span>yes</span></p>
												</hgroup>
												<hgroup>
													<p class="shortcode_detail_item_param"><strong>layout: </strong> <span>grid/masonry</span></p>
													<p class="shortcode_detail_item_param">Default: <span>grid</span></p>
												</hgroup>
												<hgroup>
													<p class="shortcode_detail_item_param"><strong>categories: </strong> <span>string of comma-separated categories i.e categories="cat_1, cat_2"</span></p>
													<p class="shortcode_detail_item_param">Default: <span>''</span></p>
												</hgroup>
											</div>
										</div>
									</div>		
								</li>
							</ol>

							
						</div>
					</div>

				</div> <!-- Close: .wise_menu_page_body -->
			</div> <!-- Close: .wise_menu_page_wrap -->
		</div> <!-- Close: #wise_menu_page -->
	</div> <!-- Close: .wrap -->

	<style>
		/* Testimonials Properties CSS */
		.shortcode_td_module_shortcode p {
			display: flex;
			align-items: center;
			gap: 10px;
		}
		.copy_shortcode_btn {
			background: none;
			/* color: blue; */
			border: none;
			/*			border-radius: 10px;*/
			/*			box-shadow: inset 0px 0px 5px -2px;*/
			cursor: pointer;
			transition: all .3s ease;
		}
		.shortcode_copied i {
			color: blue;
		}
		#wise_menu_page strong,
		.shortcode_detail_item_name {
			font-weight: 700 !important;
		}
		.shortcode_detail_item_param,
		.shortcode_detail_item_description {
			margin: 0;	
		}
		#wise_menu_page hgroup {
			margin-bottom: 15px;
		}
		.params_container,
		.shortcode_detail_item_content {
			padding-left: 20px;
		}
		.shortcode_detail_item {
			font-size: 1.5rem;
		}
		.shortcode_detail_item_param_heading {
			margin-top: 10px;
			font-size: 1.5rem;
		}
	</style>

	<script>
		let copyShortcodeBtns = document.querySelectorAll('.copy_shortcode_btn');
		if(copyShortcodeBtns.length > 0){
			copyShortcodeBtns.forEach(function(button){
				button.addEventListener('click', e => {
					console.log(button);
				    var text = button.closest('td').querySelector('.wise_shortcode').innerText;
				    window.navigator.clipboard.writeText(text).then(x => {
				        copyShortcodeBtns.forEach(v => {
				        	v.classList.remove('shortcode_copied');
				        });
				        button.classList.add('shortcode_copied');
				        setTimeout(() => {
				        	button.classList.remove('shortcode_copied');
				        }, 5 * 1000);
				    });
				});
			});
		}
	</script>

<?php
}