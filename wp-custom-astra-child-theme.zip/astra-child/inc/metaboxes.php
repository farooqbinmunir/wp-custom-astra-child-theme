<?php

// Add the testimonial metabox
function add_testimonial_properties_metabox() {
    add_meta_box(
        'wise_testimonial_properties', // ID
        'Testimonial Properties', // Title
        'testimonial_properties_callback', // Callback
        'wise-testimonials', // Post type
        'normal', // Context
        'high' // Priority
    );
}
add_action('add_meta_boxes', 'add_testimonial_properties_metabox');

// Display the metabox fields
function testimonial_properties_callback($post) {
    // Retrieve the existing metadata if available
    $testimonial_rating_image = get_post_meta($post->ID, 'testimonial_rating_image', true);
    $testimonial_person_name = get_post_meta($post->ID, 'testimonial_person_name', true);
    $testimonial_designation = get_post_meta($post->ID, 'testimonial_designation', true);
    $testimonial_review_text = get_post_meta($post->ID, 'testimonial_review_text', true);

    // Nonce field for security
    wp_nonce_field(basename(__FILE__), 'testimonial_nonce');
    ?>
    
    <p>
        <label for="testimonial_person_name">Person Name:</label><br />
        <input type="text" name="testimonial_person_name" id="testimonial_person_name" value="<?php echo esc_attr($testimonial_person_name); ?>" class="widefat" />
    </p>
    <p>
        <label for="testimonial_designation">Designation:</label><br />
        <input type="text" name="testimonial_designation" id="testimonial_designation" value="<?php echo esc_attr($testimonial_designation); ?>" class="widefat" />
    </p>
    <p>
        <label for="testimonial_review_text">Review:</label><br />
        <textarea name="testimonial_review_text" id="testimonial_review_text" rows="4" class="widefat"><?php echo esc_textarea($testimonial_review_text); ?></textarea>
    </p>
    <p>
        <label for="testimonial_rating_image">Upload Rating Image:</label><br />
        <input type="button" id="upload_image_button" class="button" value="Upload Image" />
        <input type="hidden" name="testimonial_rating_image" id="testimonial_rating_image" value="<?php echo esc_attr($testimonial_rating_image); ?>" />
        <img id="testimonial_rating_image_preview" src="<?php echo esc_url($testimonial_rating_image); ?>" style="width: 100px; height: auto; margin-top: 10px; display: block;" />
    </p>
    <script>
        jQuery(document).ready(function($) {
            var mediaUploader;
            $('#upload_image_button').click(function(e) {
                e.preventDefault();
                // If the uploader object has already been created, reopen the dialog
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                // Extend the wp.media object
                mediaUploader = wp.media.frames.file_frame = wp.media({
                    title: 'Choose Image',
                    button: {
                        text: 'Choose Image'
                    },
                    multiple: false
                });
                // When a file is selected, grab the URL and set it as the hidden input value
                mediaUploader.on('select', function() {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#testimonial_rating_image').val(attachment.url);
                    $('#testimonial_rating_image_preview').attr('src', attachment.url).show();
                });
                // Open the uploader dialog
                mediaUploader.open();
            });
        });
    </script>
    <?php
}

// Save the metabox data
function save_testimonial_metabox($post_id) {
    // Check if our nonce is set
    if (!isset($_POST['testimonial_nonce']) || !wp_verify_nonce($_POST['testimonial_nonce'], basename(__FILE__))) {
        return $post_id;
    }

    // Check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    }

    // Save testimonial name
    if (isset($_POST['testimonial_person_name'])) {
        update_post_meta($post_id, 'testimonial_person_name', sanitize_text_field($_POST['testimonial_person_name']));
    }

    // Save testimonial occupation
    if (isset($_POST['testimonial_designation'])) {
        update_post_meta($post_id, 'testimonial_designation', sanitize_text_field($_POST['testimonial_designation']));
    }

    // Save testimonial text
    if (isset($_POST['testimonial_review_text'])) {
        update_post_meta($post_id, 'testimonial_review_text', sanitize_textarea_field($_POST['testimonial_review_text']));
    }

    // Save the rating image
    if (isset($_POST['testimonial_rating_image'])) {
        update_post_meta($post_id, 'testimonial_rating_image', esc_url_raw($_POST['testimonial_rating_image']));
    }
}
add_action('save_post', 'save_testimonial_metabox');
