<?php

// Include essential files, must not be missing
require_once trailingslashit(get_stylesheet_directory()) . 'inc/utility-functions.php';

// Registering custom post types on init
function register_cpts(){
    /**
     * @function fbm_register_cpt()
     * @param  (CPT Name, Singular Name, Menu Position, hasTaxonomy, taxonomyName) 
    */
    // Registering CPT for Testimonials
    fbm_register_cpt('wise-testimonials', 'testimonial', 5, false);

    // Registering CPT for Portfolios
    fbm_register_cpt('wise-portfolios', 'portfolio', 5, true);

    // Updating permalinks after creating custom post types to avoid 'Page not found' error
    flush_rewrite_rules();
}
add_action('init', 'register_cpts');


