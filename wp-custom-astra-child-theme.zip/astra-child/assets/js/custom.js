/* Custom JavaScript/jQuery */
jQuery(document).ready($ => {
	// Use these ajax url and nonce for custom ajax requests
	const ajaxUrl = ajax.url;
	const ajaxNonce = ajax.nonce;
	// __________________________________ \\




	// Initializing Filter gallery on portfolio
	$('.layout_grid .filter-button').on('click', function() {
		$('.filter-button').removeClass('active');
		$(this).addClass('active');
        var filterValue = $(this).attr('data-filter');
        if (filterValue == 'all') {
        	$('.portfolio-item').css('width', 'calc(25% - 10px)').addClass('active');
        } else {
        	$('.portfolio-item').css('width', '0').removeClass('active');
        	$(filterValue).css('width', 'calc(25% - 10px)').addClass('active');
        }
    });
	// For Masonry Mixitup
    jQuery('.layout_masonry .portfolio-items').mixItUp({  
	    selectors: {
	      target: '.portfolio-item',
	      filter: '.filter-button',
	      sort: '.sort-btn',
	    },
	    animation: {
	        animateResizeContainer: false,
	        effects: 'fade scale'
	    },
        classNames: {
            active: 'fbm_active'
        }
	});


});


