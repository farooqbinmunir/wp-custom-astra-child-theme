<?php

// Creating shortcode for Testimonials Slider, 
// Usage: [testimonials autoplay="true" slidestoshow="3" slidestoscroll="1" dots="true" arrows="true" fade="false" infinite="true"]
function testimonials_shortcode_callback($atts){
    $default = shortcode_atts([
        'autoplay' => true,
        'slidestoshow' => 3,
        'slidestoscroll' => 1,
        'fade' => false, // fade: false means slide effect
        'dots' => true,
        'arrows' => true,
        'infinite' => true,
    ], $atts);
    ob_start();
    require trailingslashit(get_stylesheet_directory()) . 'shortcodes/slick-slider/client-testimonials.php';
    return ob_get_clean();
}
add_shortcode('testimonials', 'testimonials_shortcode_callback');

// Creating shortcode for Portfolios filter gallery, 
// Usage: [portfolios filter="yes" layout="grid" categories=""]
function portfolios_shortcode_callback($atts) {
    // Default attributes
    $default = shortcode_atts([
        'filter' => 'yes',  // Default filter is enabled
        'layout' => 'grid',  // Default layout is grid
        'categories' => '',  // Default: show all categories
    ], $atts);

    // Extract attributes
    $filter = $default['filter'];
    $categories = $default['categories'];
    $layout = $default['layout'];

    // Prepare category filter (if categories are specified)
    $category_array = [];
    if (!empty($categories)) {
        $category_slugs = explode(',', $categories);
        foreach ($category_slugs as $slug) {
            $category_array[] = sanitize_text_field(trim($slug));
        }
    }

    // Pass the data to the template
    ob_start();
    require trailingslashit(get_stylesheet_directory()) . 'shortcodes/filter-gallery/portfolios.php';
    return ob_get_clean();
}
add_shortcode('portfolios', 'portfolios_shortcode_callback');
